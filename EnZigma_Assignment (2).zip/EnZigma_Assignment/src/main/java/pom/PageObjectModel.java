package pom;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import fileUtility.ExcelFIle;

public class PageObjectModel
{
	ExcelFIle Exc = new ExcelFIle();
	public PageObjectModel(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}
	
	private @FindBy (xpath = "//a[text()='Sign up']")
	WebElement signuplink;
	
	public WebElement getsignuplink()
	{
		return signuplink;
	}
	
	public void signup()
	{
		signuplink.click();
	}
	
	
	
	private @FindBy (xpath = "(//input[@type='email'])[2]")
	WebElement userEmail;
	
	public WebElement getEmail()
	{
		return userEmail;
	}
	
	public void Email() throws EncryptedDocumentException, IOException
	{
		String Email = Exc.getData("SignUpCredentials", 0, 1);
		userEmail.sendKeys(Email);
	}
	
	private @FindBy (css = "label[class='slds-checkbox__label']")
	WebElement checkBox;
	
	public WebElement getcheckBox()
	{
		return checkBox;
	}
	
	public void clickCheckBox()
	{
		checkBox.click();
	}
	
	
	private @FindBy (xpath = "//div[text()='Proceed']")
	WebElement Proceed ;
	
	public WebElement getProceed()
	{
		return Proceed;
	}
	
	public void clickProceed()
	{
		Proceed.click();
	}	
}
